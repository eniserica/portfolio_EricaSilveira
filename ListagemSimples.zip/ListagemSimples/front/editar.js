const API = "http://localhost:3333/api/atividade";

const params = new URLSearchParams(window.location.search);
const id = params.get("id");

const inputTitulo = document.getElementById("titulo");
const inputDescricao = document.getElementById("descricao");
const btnAtualizar = document.getElementById("btnAtualizar");

async function carregarAtividade() {
  try {
    const response = await fetch(`${API}/${id}`);
    const atividade = await response.json();

    inputTitulo.value = atividade.titulo;
    inputDescricao.value = atividade.descricao;

  } catch (error) {
    alert("Erro ao carregar atividade");
  }
}

carregarAtividade();

btnAtualizar.addEventListener("click", async () => {
  const titulo = inputTitulo.value;
  const descricao = inputDescricao.value;

  if (!titulo || !descricao) {
    alert("Preencha todos os campos");
    return;
  }

  try {
    await fetch(`${API}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ titulo, descricao })
    });

    alert("Atualizado com sucesso!");
    window.location.href = "index.html";

  } catch (error) {
    alert("Erro ao atualizar");
  }
});
