const API = "http://localhost:3333/api/atividade";

const titulo = document.getElementById("titulo");
const descricao = document.getElementById("descricao");
const btnEnviar = document.querySelector(".btn-enviar");
const container = document.querySelector(".container");

// área dos cards
const atividadeCard = document.createElement("div");
atividadeCard.id = "cards";
atividadeCard.style.width = "100%";
container.appendChild(atividadeCard);

async function fetchAtividades() {
  try {
    const res = await fetch(API);
    const data = await res.json();
    renderizarCard(data);
  } catch (err) {
    console.error("Erro ao buscar atividades:", err);
  }
}

function renderizarCard(list) {
  atividadeCard.innerHTML = "";
  if (!Array.isArray(list) || list.length === 0) {
    atividadeCard.innerHTML = "<p style='color:#fff'>Nenhuma atividade encontrada.</p>";
    return;
  }
  list.forEach(a => {
    const card = document.createElement("div");
    card.className = "card-atividade";
    card.innerHTML = `
      <h2>${escapeHtml(a.titulo)}</h2>
      <p>${escapeHtml(a.descricao)}</p>
      <section>
        <button class="btn-editar" data-id="${a.id}">Editar</button>
        <button class="btn-excluir" data-id="${a.id}">Excluir</button>
      </section>
    `;
    atividadeCard.appendChild(card);
  });
}

function escapeHtml(str) {
  return String(str || "").replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  })[c]);
}

btnEnviar.addEventListener("click", async () => {
  const titulo = titulo.value.trim();
  const descricao = descricao.value.trim();
  if (!titulo || !descricao) {
    alert("Preencha título e descrição");
    return;
  }

  try {
    const res = await fetch(API, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ titulo, descricao })
    });
    if (res.ok) {
      titulo.value = "";
      descricao.value = "";
      fetchAtividades();
    } else {
      const e = await res.json();
      alert(e.mensagem || "Erro ao criar atividade");
    }
  } catch (err) {
    console.error("Erro ao criar atividade:", err);
    alert("Erro de conexão com o backend");
  }
});

// editar/excluir
document.addEventListener("click", async (e) => {
  if (e.target.matches(".btn-excluir")) {
    const id = e.target.dataset.id;
    if (!confirm("Confirmar exclusão?")) return;
    try {
      await fetch(`${API}/${id}`, { method: "DELETE" });
      fetchAtividades();
    } catch (err) {
      console.error(err);
      alert("Erro ao excluir");
    }
  }

  if (e.target.matches(".btn-editar")) {
  const id = e.target.dataset.id;
  window.location.href = `btnEditar.html?id=${id}`;
}
});

fetchAtividades();