import app from "./app.js"

const PORT = 3333;

app.listen(PORT, () => {
    console.log(`Servidor on http://localhost:${PORT}`)
});