import { Router } from "express";
import { criarAtividade, listarAtividades, listarUmaAtividade, atualizarAtividade, deletarAtividade } from "./atividadeController.js";

const router = Router();

router.post("/", criarAtividade);
router.get("/", listarAtividades);
router.get("/:id", listarUmaAtividade);
router.put("/:id", atualizarAtividade);
router.delete("/:id", deletarAtividade);

export default router;