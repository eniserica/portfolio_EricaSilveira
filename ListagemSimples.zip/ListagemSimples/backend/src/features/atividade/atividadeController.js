import { atividadeModel } from "./atividadeModel.js";

export const criarAtividade = async (request,response, next) => {
    const {titulo, descricao} = request.body;  

    if(!titulo){
        return response.status(400).json({
            mensagem: "O campo título é obrigatório."
    })}
    if(!descricao){
        return response.status(400).json({
            mensagem: "O campo descricao é obrigatório."
    })}

    try {
        const atividade = {
            titulo,
            descricao
        }

        const novaAtividade = await atividadeModel.create(atividade);

       return response.status(201).json(novaAtividade);
    } catch (error) {
        next(error)
    }

}

export const listarAtividades = async (request, response, next) => {
    try{
        const atividade = await atividadeModel.findAll({
            attributes: { exclude: ['updated_at', 'created_at'] } 
        });
        
        return response.status(200).json(atividade);
    }catch(error){
        next(error)
    }
}

export const listarUmaAtividade = async (request, response, next) => {

    const id = request.params.id;

    try {

        const atividade = await atividadeModel.findByPk(id);

        if (!atividade) {
            const error = new Error("Atividade não encontrado.");
            error.statusCode = 404;
            throw error;
        }
        
        return response.status(200).json(atividade);
    } catch (error) {
        next(error);
    }
}

export const atualizarAtividade = async (request, response, next) => {
    const id = request.params.id;
    const { titulo, descricao } = request.body;

     if(!titulo){
        return response.status(400).json({
            mensagem: "O campo título é obrigatório."
    })}
    if(!descricao){
        return response.status(400).json({
            mensagem: "O campo descricao é obrigatório."
    })}

    try{
        const atividadeId = await atividadeModel.findByPk(id);
         if (!atividadeId) {
            const error = new Error("Atividade não encontrado.");
            error.statusCode = 404;
            throw error;
        }

        const atividade ={
            titulo,
            descricao
        }

        const atividadeAtualizada = await atividadeModel.update(atividade, { where: { id: id } });

        return response.status(200).json({mensagem: "Atividade atualizada com sucesso", atividadeAtualizada, atividade});
    }catch(error){
        next(error)
    }

}

export const deletarAtividade = async (request, response, next) => {
    const id = request.params.id;
    try {
          const atividadeDeletada = await atividadeModel.destroy({
            where: { id: id }
        });

        if (atividadeDeletada === 0) {
            const error = new Error("Atividade não encontrado.");
            error.statusCode = 404;
            throw error;
        }

        return response.status(200).json({ mensagem: "Atividade excluída com sucesso." });   
    }catch(error){
        next(error)
    }
}