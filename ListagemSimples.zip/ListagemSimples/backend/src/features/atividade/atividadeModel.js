import {DataTypes} from "sequelize";
import {conn} from "../../config/sequelize.js"

export const atividadeModel = conn.define(
    "atividades",
    {
        titulo:{
            type: DataTypes.STRING,
            allowNull: false
        },
        descricao: {
            type: DataTypes.STRING,
            allowNull: false
        }
     
    },
    {
        timestamps: true,
        createdAt: "created_at",
        updatedAt: "updated_at",
    }
)