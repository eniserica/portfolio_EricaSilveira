import express from "express";
import cors from "cors";
import { errorHandler } from "./shared/error/errorHandler.js"
import { conn } from "./config/sequelize.js";


// Importação das tabelas 
import "./features/atividade/atividadeModel.js"

//Importação das rotas
import atividadeRoutes from "./features/atividade/atividadeRoutes.js";


const app = express();

conn.sync();

app.use(cors({
    origin: "*",
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE" ],
    credentials: true
}));

app.use(express.json());


//consumo das rotas
app.use("/api/atividade", atividadeRoutes);



//404 na rota 
app.use((request, response) => {
    response.status(404).json({
        success: false,
        statusCode: 404,
        message: "Rota não encontrada",
    });
});

//error handler
app.use(errorHandler);


export default app;