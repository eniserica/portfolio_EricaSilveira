import './App.css'
import foto1 from "./images/foto-1.jpg";
import foto2 from "./images/foto-2.jpg";
import foto3 from "./images/foto-3.png"
function App() {

  return (
    <body>
    <header>
      <nav>
        <a href='#'>Inicio</a>
        <a href='#'>Contato</a>
      </nav>
    </header>
    <main>
      <section className='hero'>
        <h1>Conexão Digital 2025</h1>
        <h4>Junte-se a nós para um dia repleto de inovações e oportunidades.</h4>
        <button className='btn-inscrever'>Inscreva-se</button>
      </section>

      <section className='descricao'>
        <h5>O Conexão Digital 2025 é um evento focado em tendências tecnológicas, experiências de usuários e desenvolvimento de produtos digitais. Reúne profissionais, estudantes e empresas que buscam descobrir novas soluções, discutir desafios atuais e construir o futuro da tecnologia no Brasil.</h5>
        <div className='colunas'>
          <div className='coluna-1'>
            <h5>Data: 15 de novembro de 2025</h5>
            <h5>Horário: 09h às 18h30</h5>
          </div>
          <div className='coluna-2'>
            <h5>Local: Centro de Convenções Aurora Av. das Nações, 3200 - Belo Horizonte, MG</h5>
          </div>
        </div>

        <section className='palestrantes'>
           <h2>Palestrantes</h2>
          <div className='container-palestrantes'>
            <section className='palestrante'>
            <img src = {foto2}/>
            <p>Davi Santos</p>
            <p>Desenvolvedor FullStack</p>
            </section>

            <section className='palestrante'> 
            <img src ={foto1}/>
            <p>Raquel Vieira</p>
            <p>Designer UI/UX</p>
            </section>
            
            <section className='palestrante'>
            <img src ={foto3}/>
            <p>Rodrigo Barbosa</p>
            <p>Desenvolvedor Frontend</p>
            </section>
           
          </div>
          
        </section>
      </section>
    </main>
    <footer>
      <h2>Perguntas Frequentes</h2>
      <h4>Qual o foco principal do evento?</h4>
      <p>O evento foca em inovação tecnológica.</p>
      <h4>Quem deve participar do evento? </h4>
      <p>É destinando a estudantes, profissionais e entusiatas de tecnologia.</p>
      <h4>Como faço para me inscrever no evento?</h4>
      <p>Basta clicar no botão de “inscreva-se” no site e preencher o formulário.</p>
    </footer>
    </body>
  )
}

export default App
