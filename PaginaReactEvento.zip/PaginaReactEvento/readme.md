# Projeto com base no Figma 
## Link do figma: 
https://www.figma.com/design/w5sQAdke7BSO9lkphTsN0Y/Untitled?node-id=0-1&t=Jq5UNlKcnxalwIWP-1


# Conexão Digital 2025 – Página de Evento

Este projeto é uma página fictícia de divulgação de evento criada para demonstrar habilidades em HTML, CSS e JavaScript, com foco em UI, responsividade e boas práticas de front-end.

# Objetivo do Projeto

Construir uma landing page moderna e responsiva para um evento de tecnologia.

# Seções da Página

- Cabeçalho com navegação
- Hero com título do evento e botão “Inscreva-se”
- Descrição detalhada do evento
- Informações gerais (data, horário, local)
- Lista de palestrantes com fotos e cargos
- FAQ (Perguntas Frequentes)


# Tecnologias Utilizadas

- React.js
- JavaScript 
- Flexbox / Grid
- Design responsivo (mobile-first)

# Habilidades Demonstradas
- Estruturação de layout
- Componentização simples
- Organização de estilos
- Responsividade
- Design limpo e funcional
- Boas práticas de semântica HTML